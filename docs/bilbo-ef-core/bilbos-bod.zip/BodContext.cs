using Microsoft.EntityFrameworkCore;

public class BodContext : DbContext
{
    public DbSet<Jam> Jams => Set<Jam>();

    protected override void OnConfiguring(DbContextOptionsBuilder options)
    {
        var connection = Environment.GetEnvironmentVariable("BILBO_DB")
            ?? throw new InvalidOperationException("Sæt BILBO_DB i terminalen.");
        options.UseNpgsql(connection);
    }

    protected override void OnModelCreating(ModelBuilder model)
    {
        model.Entity<Jam>().HasIndex(jam => jam.Name).IsUnique();
    }
}
