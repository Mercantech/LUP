# Bilbos marmeladebod

Gem et glas brombærmarmelade i PostgreSQL, luk programmet, og læs navnet igen i en ny proces. Eksemplet følger Bilbo Backends video og bruger .NET 10, EF Core 10 og PostgreSQL 17.

## Kør det færdige eksempel

Du skal bruge .NET 10 SDK, Docker med Compose og PowerShell 7.1 eller nyere. Start Docker. Pak ZIP-filen ud, og åbn en terminal i mappen med `BilbosBod.csproj`.

Vælg et langt lokalt øvelseskodeord med bogstaver og cifre. Det gør det muligt at samle forbindelsesstrengen som i filmen. I et nyt terminalvindue skal du indtaste det samme kodeord igen. Databasen husker kodeordet fra første start.

```powershell
$env:POSTGRES_PASSWORD = Read-Host -MaskInput 'Lokalt kodeord'
$env:BILBO_DB = "Host=localhost;Port=55432;Database=bilbo;Username=bilbo;Password=$env:POSTGRES_PASSWORD"
docker compose up -d --wait
dotnet restore
dotnet tool restore
dotnet ef database update
dotnet run -- gem
dotnet run
```

Ved første opdatering kan EF logge en fejlet læsning fra `__EFMigrationsHistory`, fordi den nye database endnu mangler migrationstabellen. Fortsæt, når opdateringen viser `Applying migration` og derefter `Done.`.

Den første programkørsel skriver `Gemt: Brombær`. Den næste starter en ny proces, læser rækken fra PostgreSQL og skriver `Læst: Brombær`. Hvis du gentager `dotnet run -- gem`, fortæller Bilbo, at marmeladen allerede er gemt.

Se også rækken direkte i PostgreSQL. Åbn `psql` med den første kommando, og skriv SQL-forespørgslen ved databasens prompt.

```powershell
docker compose exec db psql -U bilbo -d bilbo
```

```sql
SELECT "Id", "Name" FROM "Jams";
```

Resultatet har én række med `1` og `Brombær` i en ny database. Afslut `psql` med `\q`. Stop derefter databasen med `docker compose stop`. Den navngivne Docker-volumen gemmer rækkerne til næste gang.

## Byg projektet som i videoen

Åbn en tom arbejdsmappe, og opret konsolappen. Npgsql-pakken henter EF Core og oversætter forespørgsler til PostgreSQL. Design-pakken giver EF-værktøjet adgang til modellen. Det lokale værktøjsmanifest gemmer versionen af `dotnet-ef` sammen med projektet.

```powershell
dotnet new console -n BilbosBod -f net10.0
cd BilbosBod
dotnet add package Npgsql.EntityFrameworkCore.PostgreSQL --version 10.0.4
dotnet add package Microsoft.EntityFrameworkCore.Design --version 10.0.15
dotnet new tool-manifest
dotnet tool install dotnet-ef --version 10.0.15
```

Kopiér `Jam.cs`, `BodContext.cs` og `compose.yaml` fra eksemplet, og erstat projektets `Program.cs` med filen fra eksemplet. `Jam` beskriver et glas med `Id` og `Name`. `DbSet<Jam> Jams` knytter typen til tabellen `Jams`. `UseNpgsql(connection)` vælger udbyderen og bruger forbindelsesstrengen fra `BILBO_DB`.

Kør de to linjer ovenfor, der sætter terminalens miljøvariabler, og kør derefter disse kommandoer i det nye projekt.

```powershell
docker compose up -d --wait
dotnet ef migrations add FoersteMigration
dotnet ef database update
dotnet run -- gem
dotnet run
```

`migrations add` opretter C#-filer i `Migrations/`. Se `CreateTable` i migrationsfilen for at finde tabellen og dens kolonner. `database update` bruger migrationen til at oprette tabellen i PostgreSQL. ZIP-filen indeholder allerede den første migration til dem, der følger det færdige eksempel.

## Kør også konsolappen i Docker

Når migrationen er anvendt, kan `app` køre i en container. Kopiér også `Dockerfile` og `.dockerignore`, hvis du har oprettet projektet fra bunden. Inde på Compose-netværket bruger appen `db:5432`. Et program startet fra din terminal bruger `localhost:55432`.

```powershell
docker compose build app
docker compose run --rm app gem
docker compose run --rm app
```

## Kilder

- [Npgsql om PostgreSQL-udbyderen, modellen og UseNpgsql](https://www.npgsql.org/efcore/)
- [Microsoft Learn om EF Core-værktøjer og migrationer](https://learn.microsoft.com/en-us/ef/core/cli/dotnet)
- [Docker om postgres-imaget og dets miljøvariabler](https://hub.docker.com/_/postgres)

