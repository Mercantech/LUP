using Microsoft.EntityFrameworkCore;

await using var db = new BodContext();

if (args is ["gem"])
{
    if (await db.Jams.AnyAsync(jam => jam.Name == "Brombær"))
    {
        Console.WriteLine("Brombær er allerede gemt.");
        return;
    }

    db.Jams.Add(new Jam { Name = "Brombær" });
    await db.SaveChangesAsync();
    Console.WriteLine("Gemt: Brombær");
    return;
}

if (args.Length > 0)
{
    Console.Error.WriteLine("Brug dotnet run eller dotnet run -- gem.");
    Environment.ExitCode = 1;
    return;
}

var names = await db.Jams.OrderBy(jam => jam.Id)
    .Select(jam => jam.Name)
    .ToListAsync();
foreach (var name in names)
{
    Console.WriteLine($"Læst: {name}");
}
