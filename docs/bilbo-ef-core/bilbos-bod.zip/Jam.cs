public class Jam
{
    public int Id { get; set; }
    public required string Name { get; set; }
}
